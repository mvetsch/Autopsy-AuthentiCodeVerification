# Autopsy-AuthentiCodeVerification
Autopsy Module to verify Microsoft AuthentiCode Signatures on Data Source

## Downloads
A compiled verion of this module can be downloaded here: http://www.nitcorn.ch/org-sleuthkit-autopsy-modules-authenticode.nbm
