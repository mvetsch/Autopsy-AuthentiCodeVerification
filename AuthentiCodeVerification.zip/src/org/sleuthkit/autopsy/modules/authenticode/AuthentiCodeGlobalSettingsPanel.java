
package org.sleuthkit.autopsy.modules.authenticode;

import org.sleuthkit.autopsy.ingest.IngestModuleGlobalSettingsPanel;

public class AuthentiCodeGlobalSettingsPanel extends IngestModuleGlobalSettingsPanel {

    @Override
    public void saveSettings() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}
